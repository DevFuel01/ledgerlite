# LedgerLite

> A lightweight financial operating system for informal institutions

LedgerLite is a production-ready web application designed to help private schools, training centers, community programs, and small organizations manage their finances efficiently. Built with simplicity, security, and usability in mind.

## 🎯 Features

### Core Functionality
- **User Authentication** - Secure registration and login with password hashing
- **Institution Management** - Create and manage institution profiles
- **Payment Recording** - Quick and easy payment entry with validation
- **Auto-Generated Receipts** - Professional receipts with unique transaction IDs
- **Real-Time Dashboard** - View total, daily, and monthly income at a glance
- **Transaction History** - Complete payment history with pagination and date filtering
- **Audit Logging** - Comprehensive activity tracking for security and compliance

### Key Benefits
- ✅ **Easy to Use** - Intuitive interface designed for non-technical users
- ✅ **Secure** - Built with security best practices (PDO, password hashing, CSRF protection)
- ✅ **Fast** - Lightweight and optimized for performance
- ✅ **Responsive** - Works seamlessly on desktop, tablet, and mobile devices
- ✅ **Production-Ready** - Clean code, proper error handling, and comprehensive validation

## 🛠️ Tech Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Custom styles with modern design
- **Bootstrap 5** - Responsive UI framework
- **Vanilla JavaScript** - No dependencies, pure JS

### Backend
- **PHP 8+** - Server-side logic
- **PDO** - Secure database access (no raw SQL)
- **MySQL 8+** - Relational database

### Hosting
- **XAMPP Compatible** - Works with local development
- **Replit Ready** - Deploy instantly to Replit

## 📁 Project Structure

```
LedgerLite/
├── auth/                       # Authentication module
│   ├── register.php           # User registration page
│   ├── register_handler.php   # Registration logic
│   ├── login.php              # Login page
│   ├── login_handler.php      # Login logic
│   └── logout.php             # Logout handler
├── dashboard/                  # Dashboard module
│   ├── index.php              # Main dashboard
│   ├── get_stats.php          # Statistics API
│   └── get_transactions.php   # Transaction history API
├── payments/                   # Payment module
│   ├── record_payment.php     # Payment recording form
│   └── process_payment.php    # Payment processing logic
├── receipts/                   # Receipt module
│   └── view_receipt.php       # Receipt display & print
├── institution/                # Institution module
│   └── profile.php            # Institution profile management
├── config/                     # Configuration files
│   ├── database.php           # PDO database connection
│   └── config.php             # Application settings
├── includes/                   # Shared utilities
│   ├── security.php           # Security helper functions
│   ├── functions.php          # Utility functions
│   ├── header.php             # Reusable header
│   └── footer.php             # Reusable footer
├── assets/                     # Frontend assets
│   ├── css/
│   │   └── main.css           # Custom styles
│   └── js/
│       ├── common.js          # Shared JavaScript utilities
│       ├── dashboard.js       # Dashboard functionality
│       └── payment.js         # Payment form handling
├── database/                   # Database files
│   └── schema.sql             # Complete database schema
├── index.php                   # Landing page
└── README.md                   # This file
```

## 🚀 Setup Instructions

### Prerequisites
- PHP 8.0 or higher
- MySQL 8.0 or higher
- Web server (Apache/Nginx) or XAMPP

### Local Setup (XAMPP)

1. **Clone or Download**
   ```bash
   # Place the LedgerLite folder in your htdocs directory
   C:\xampp\htdocs\LedgerLite
   ```

2. **Create Database**
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Create a new database named `ledgerlite`
   - Import the schema:
     - Click on the `ledgerlite` database
     - Go to "Import" tab
     - Choose file: `database/schema.sql`
     - Click "Go"

3. **Configure Database Connection**
   - Open `config/database.php`
   - Update credentials if needed (default works for XAMPP):
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'ledgerlite');
     define('DB_USER', 'root');
     define('DB_PASS', '');
     ```

4. **Update Application URL**
   - Open `config/config.php`
   - Update `APP_URL` to match your setup:
     ```php
     define('APP_URL', 'http://localhost/LedgerLite');
     ```

5. **Start XAMPP**
   - Start Apache and MySQL services
   - Visit: http://localhost/LedgerLite

### Replit Setup

1. **Create New Repl**
   - Choose "PHP Web Server" template
   - Upload all LedgerLite files

2. **Setup Database**
   - Replit provides MySQL automatically
   - Import `database/schema.sql` via phpMyAdmin or command line

3. **Configure**
   - Update `config/database.php` with Replit's database credentials
   - Update `config/config.php` with your Repl URL

4. **Run**
   - Click "Run" button
   - Your app will be live!


## 📊 Database Schema

### Tables

1. **institutions** - Organization profiles
2. **users** - Admin user accounts
3. **payments** - Payment transactions
4. **receipts** - Receipt metadata
5. **audit_logs** - Activity tracking

### Relationships
- One institution has many users
- One institution has many payments
- One payment has one receipt
- All actions are logged in audit_logs

See `database/schema.sql` for complete schema with indexes and constraints.

## 🔒 Security Features

### Implemented Security Measures

1. **SQL Injection Prevention**
   - All queries use PDO prepared statements
   - No string concatenation in SQL

2. **XSS Protection**
   - All output is sanitized with `htmlspecialchars()`
   - Input sanitization helper functions

3. **CSRF Protection**
   - Token generation and validation for all forms
   - Session-based token storage

4. **Password Security**
   - Passwords hashed using `password_hash()` with bcrypt
   - Verification using `password_verify()`

5. **Session Security**
   - Session timeout (1 hour)
   - Session regeneration on login
   - Secure session configuration

6. **Authentication**
   - Protected routes with `check_auth()`
   - Institution-level data isolation
   - Failed login attempt logging

7. **Audit Trail**
   - All critical actions logged
   - IP address and user agent tracking
   - Timestamp recording

## 🎨 UI/UX Features

- **Clean Dashboard** - Modern, card-based layout
- **Responsive Design** - Mobile, tablet, and desktop optimized
- **Real-Time Updates** - AJAX-powered statistics and transactions
- **Professional Receipts** - Print-ready receipt design
- **Loading States** - Visual feedback for all actions
- **Error Handling** - User-friendly error messages
- **Form Validation** - Client and server-side validation

## 📝 Usage Guide

### Recording a Payment

1. Login to your account
2. Click "Record New Payment" button
3. Fill in the payment details:
   - Payer name
   - Amount
   - Payment purpose
   - Payment method
   - Payment date
   - Optional notes
4. Click "Record Payment"
5. View or print the auto-generated receipt

### Viewing Dashboard

The dashboard displays:
- **Total Income** - All-time total
- **Today's Income** - Payments received today
- **This Month** - Current month's total
- **Transaction History** - Paginated list with filters

### Managing Institution Profile

1. Click on your name in the navigation
2. Select "Institution Profile"
3. Update institution details
4. Click "Update Profile"

## 🚧 Future Enhancements

Potential improvements for post-hackathon:

- [ ] Multi-user roles (admin, accountant, viewer)
- [ ] PDF receipt generation (using TCPDF or similar)
- [ ] Email notifications for payments
- [ ] SMS receipt delivery
- [ ] Advanced reporting with charts
- [ ] Data export (CSV, Excel)
- [ ] Bulk payment import
- [ ] Two-factor authentication
- [ ] API for mobile apps
- [ ] Payment reminders
- [ ] Expense tracking
- [ ] Budget management

## 🐛 Troubleshooting

### Database Connection Error
- Check MySQL is running
- Verify database credentials in `config/database.php`
- Ensure database `ledgerlite` exists

### Session Issues
- Check PHP session configuration
- Ensure `session_start()` is called
- Clear browser cookies

### Permission Errors
- Ensure proper file permissions (755 for directories, 644 for files)
- Check Apache/PHP has write access if needed

## 📄 License

This project is open-source and available for educational and commercial use.

## 👨‍💻 Development

### Code Standards
- PSR-12 coding style for PHP
- Semantic HTML5
- BEM methodology for CSS (where applicable)
- ES6+ JavaScript

### Testing Checklist
- [x] User registration and login
- [x] Payment recording
- [x] Receipt generation
- [x] Dashboard statistics
- [x] Transaction history
- [x] Date filtering
- [x] Institution profile update
- [x] Security measures
- [x] Responsive design
- [x] Error handling

## 🏆 Hackathon Notes

**Why LedgerLite Stands Out:**

1. **Complete Solution** - Not just a prototype, fully functional MVP
2. **Production-Ready** - Clean code, proper security, error handling
3. **User-Focused** - Designed for real users, not developers
4. **Well-Documented** - Comprehensive README and code comments
5. **Scalable Architecture** - Easy to extend and maintain
6. **Modern Tech** - Uses current best practices
7. **Real-World Impact** - Solves actual problems for institutions

## 📞 Support

For issues or questions:
- Check the troubleshooting section
- Review code comments
- Inspect browser console for errors
- Check PHP error logs

---

**Built with ❤️ for institutions that need simple, effective financial management.**

*LedgerLite - Making financial management accessible to everyone.*
