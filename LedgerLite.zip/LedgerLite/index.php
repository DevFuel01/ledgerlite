<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LedgerLite - Financial Operating System for Institutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }
    </style>
</head>

<body>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">LedgerLite</h1>
                    <p class="lead mb-4">A lightweight financial operating system designed for informal institutions, private schools, training centers, and community programs.</p>
                    <p class="mb-4">Simplify payment recording, generate receipts automatically, and track your finances in real-time.</p>
                    <div class="d-flex gap-3">
                        <a href="auth/register.php" class="btn btn-light btn-lg">Get Started</a>
                        <a href="auth/login.php" class="btn btn-outline-light btn-lg">Login</a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="assets/images/hero-dashboard.png" alt="LedgerLite Dashboard" class="img-fluid rounded-3 shadow-lg" style="max-width: 100%; height: auto;">
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Why Choose LedgerLite?</h2>
                <p class="text-muted">Everything you need to manage institutional finances efficiently</p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Easy Payment Recording</h5>
                        <p class="text-muted">Record payments quickly with our intuitive form. Capture payer details, amount, purpose, and payment method in seconds.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Auto-Generated Receipts</h5>
                        <p class="text-muted">Professional receipts are generated automatically for every payment with unique transaction IDs and receipt numbers.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Real-Time Dashboard</h5>
                        <p class="text-muted">Track total income, today's income, and monthly income at a glance. View complete transaction history with filters.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Secure & Safe</h5>
                        <p class="text-muted">Built with security in mind. Password hashing, CSRF protection, SQL injection prevention, and comprehensive audit logging.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M17 10H7v2h10v-2zm2-7h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zm-5-5H7v2h7v-2z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Transaction History</h5>
                        <p class="text-muted">Complete transaction history with pagination and date filtering. Search and review all payments easily.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="text-center">
                        <div class="feature-icon mx-auto">
                            <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                            </svg>
                        </div>
                        <h5 class="fw-bold">Multi-Institution Support</h5>
                        <p class="text-muted">Each institution has its own isolated data. Perfect for schools, training centers, and community programs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Tech Stack Section -->
    <section class="bg-light py-5">
        <div class="container">
            <div class="text-center mb-4">
                <h2 class="fw-bold">Built With Modern Technology</h2>
                <p class="text-muted">Clean, simple, and production-ready</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="row text-center">
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">HTML5</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">CSS3</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">Bootstrap 5</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">JavaScript</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">PHP</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">MySQL</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">PDO</h6>
                            </div>
                        </div>
                        <div class="col-6 col-md-3 mb-3">
                            <div class="bg-white p-3 rounded shadow-sm">
                                <h6 class="mb-0">Replit Ready</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-5">
        <div class="container text-center">
            <h2 class="fw-bold mb-4">Ready to Get Started?</h2>
            <p class="lead mb-4">Join institutions already using LedgerLite to manage their finances</p>
            <div class="d-flex gap-3 justify-content-center">
                <a href="auth/register.php" class="btn btn-primary btn-lg">Create Free Account</a>
                <a href="auth/login.php" class="btn btn-outline-primary btn-lg">Login</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2026 LedgerLite. Built for hackathons, ready for production.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>