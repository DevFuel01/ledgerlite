<?php

/**
 * Footer Component
 * LedgerLite - Financial Operating System
 */
?>
<footer class="bg-light mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p class="mb-0 text-muted">&copy; <?php echo date('Y'); ?> LedgerLite. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0 text-muted">Version <?php echo APP_VERSION; ?></p>
            </div>
        </div>
    </div>
</footer>