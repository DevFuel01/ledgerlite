<?php

/**
 * Security Helper Functions
 * LedgerLite - Financial Operating System
 * 
 * Provides security utilities for authentication, CSRF protection,
 * input sanitization, and transaction ID generation.
 */

/**
 * Sanitize user input to prevent XSS attacks
 * 
 * @param string $data Raw input data
 * @return string Sanitized data
 */
function sanitize_input($data)
{
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Generate CSRF token and store in session
 * 
 * @return string CSRF token
 */
function generate_csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token from form submission
 * 
 * @param string $token Token to verify
 * @return bool True if valid, false otherwise
 */
function verify_csrf_token($token)
{
    if (!isset($_SESSION['csrf_token']) || !isset($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Check if user is authenticated
 * Redirects to login if not authenticated
 * 
 * @param bool $redirect Whether to redirect or just return false
 * @return bool True if authenticated
 */
function check_auth($redirect = true)
{
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['institution_id'])) {
        if ($redirect) {
            header('Location: ' . APP_URL . '/auth/login.php');
            exit();
        }
        return false;
    }

    // Check session timeout
    if (isset($_SESSION['last_activity'])) {
        $elapsed = time() - $_SESSION['last_activity'];
        if ($elapsed > SESSION_TIMEOUT) {
            session_destroy();
            if ($redirect) {
                header('Location: ' . APP_URL . '/auth/login.php?timeout=1');
                exit();
            }
            return false;
        }
    }

    // Update last activity time
    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Get current user ID from session
 * 
 * @return int|null User ID or null if not logged in
 */
function get_user_id()
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current institution ID from session
 * 
 * @return int|null Institution ID or null if not logged in
 */
function get_institution_id()
{
    return $_SESSION['institution_id'] ?? null;
}

/**
 * Generate unique transaction ID
 * Format: TXN-YYYY-NNNN
 * 
 * @param PDO $pdo Database connection
 * @return string Unique transaction ID
 */
function generate_transaction_id($pdo)
{
    $year = date('Y');
    $prefix = "TXN-{$year}-";

    // Get the last transaction ID for this year
    $stmt = $pdo->prepare("
        SELECT transaction_id 
        FROM payments 
        WHERE transaction_id LIKE :prefix 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->execute(['prefix' => $prefix . '%']);
    $last = $stmt->fetch();

    if ($last) {
        // Extract number and increment
        $lastNumber = (int) substr($last['transaction_id'], -4);
        $newNumber = $lastNumber + 1;
    } else {
        // First transaction of the year
        $newNumber = 1;
    }

    // Format with leading zeros
    return $prefix . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

/**
 * Generate unique receipt number
 * Format: RCP-YYYY-NNNN
 * 
 * @param PDO $pdo Database connection
 * @return string Unique receipt number
 */
function generate_receipt_number($pdo)
{
    $year = date('Y');
    $prefix = "RCP-{$year}-";

    // Get the last receipt number for this year
    $stmt = $pdo->prepare("
        SELECT receipt_number 
        FROM receipts 
        WHERE receipt_number LIKE :prefix 
        ORDER BY id DESC 
        LIMIT 1
    ");
    $stmt->execute(['prefix' => $prefix . '%']);
    $last = $stmt->fetch();

    if ($last) {
        $lastNumber = (int) substr($last['receipt_number'], -4);
        $newNumber = $lastNumber + 1;
    } else {
        $newNumber = 1;
    }

    return $prefix . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

/**
 * Log action to audit trail
 * 
 * @param PDO $pdo Database connection
 * @param string $action Action performed
 * @param string|null $entity_type Type of entity affected
 * @param int|null $entity_id ID of entity affected
 * @param string|null $description Additional description
 * @return bool Success status
 */
function log_audit($pdo, $action, $entity_type = null, $entity_id = null, $description = null)
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs 
            (user_id, institution_id, action, entity_type, entity_id, description, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        return $stmt->execute([
            get_user_id(),
            get_institution_id(),
            $action,
            $entity_type,
            $entity_id,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (PDOException $e) {
        error_log("Audit log error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get client IP address
 * 
 * @return string IP address
 */
function get_client_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    }
}

/**
 * Send JSON response and exit
 * 
 * @param bool $success Success status
 * @param string $message Response message
 * @param array $data Additional data
 */
function json_response($success, $message, $data = [])
{
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit();
}
