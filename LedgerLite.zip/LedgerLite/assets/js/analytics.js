/**
 * Analytics JavaScript
 * LedgerLite - Financial Operating System
 */

// Load analytics on page load
document.addEventListener('DOMContentLoaded', function() {
    loadAnalytics();
});

// Load analytics data
async function loadAnalytics() {
    try {
        const response = await fetchAPI('get_analytics.php');
        
        if (response.success) {
            const data = response.data;
            
            // Update highest day
            document.getElementById('highestDay').textContent = data.highest_day.formatted_date;
            document.getElementById('highestDayAmount').textContent = data.highest_day.formatted;
            
            // Update average daily income
            document.getElementById('avgDaily').textContent = data.avg_daily_income.formatted;
            
            // Render payment method chart
            renderMethodChart(data.payment_methods);
            
            // Render monthly trend chart
            renderTrendChart(data.monthly_trend);
            
            // Render top payers
            renderTopPayers(data.top_payers);
        } else {
            console.error('Failed to load analytics:', response.message);
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

// Render payment method breakdown chart
function renderMethodChart(methods) {
    const ctx = document.getElementById('methodChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: methods.map(m => m.method_formatted),
            datasets: [{
                data: methods.map(m => m.total),
                backgroundColor: [
                    '#0d6efd',
                    '#198754',
                    '#ffc107',
                    '#dc3545',
                    '#6c757d'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + methods[context.dataIndex].formatted;
                        }
                    }
                }
            }
        }
    });
}

// Render monthly trend chart
function renderTrendChart(trend) {
    const ctx = document.getElementById('trendChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: trend.map(t => t.month),
            datasets: [{
                label: 'Monthly Income',
                data: trend.map(t => t.total),
                borderColor: '#0d6efd',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return trend[context.dataIndex].formatted;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Render top payers table
function renderTopPayers(payers) {
    const tbody = document.getElementById('topPayersTable');
    
    if (payers.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No data available</td></tr>';
        return;
    }
    
    tbody.innerHTML = payers.map((p, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${p.name}</td>
            <td>${p.payment_count} payment${p.payment_count > 1 ? 's' : ''}</td>
            <td class="text-end fw-bold">${p.formatted}</td>
        </tr>
    `).join('');
}
