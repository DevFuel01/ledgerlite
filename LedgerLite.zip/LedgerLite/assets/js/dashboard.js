/**
 * Dashboard JavaScript
 * LedgerLite - Financial Operating System
 */

let currentPage = 1;
let startDate = '';
let endDate = '';

// Load statistics on page load
document.addEventListener('DOMContentLoaded', function() {
    loadStatistics();
    loadTransactions();
    
    // Date filter listeners
    document.getElementById('startDate').addEventListener('change', function() {
        startDate = this.value;
        currentPage = 1;
        loadTransactions();
    });
    
    document.getElementById('endDate').addEventListener('change', function() {
        endDate = this.value;
        currentPage = 1;
        loadTransactions();
    });
});

// Load statistics
async function loadStatistics() {
    try {
        const response = await fetchAPI('get_stats.php');
        
        if (response.success) {
            document.getElementById('totalIncome').textContent = response.data.formatted.total_income;
            document.getElementById('todayIncome').textContent = response.data.formatted.today_income;
            document.getElementById('monthIncome').textContent = response.data.formatted.month_income;
        } else {
            console.error('Failed to load statistics:', response.message);
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

// Load transactions
async function loadTransactions(page = 1) {
    currentPage = page;
    
    // Build URL with parameters
    let url = `get_transactions.php?page=${page}`;
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;
    
    try {
        const response = await fetchAPI(url);
        
        if (response.success) {
            renderTransactions(response.data.transactions);
            renderPagination(response.data.pagination);
        } else {
            document.getElementById('transactionTable').innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">${response.message}</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
        document.getElementById('transactionTable').innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-danger">Failed to load transactions</td>
            </tr>
        `;
    }
}

// Render transactions table
function renderTransactions(transactions) {
    const tbody = document.getElementById('transactionTable');
    
    if (transactions.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-muted">No transactions found</td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = transactions.map(t => `
        <tr class="fade-in">
            <td>${t.payment_date_formatted}</td>
            <td><span class="badge bg-secondary">${t.transaction_id}</span></td>
            <td>${t.payer_name}</td>
            <td>${t.payment_purpose}</td>
            <td>${t.payment_method_formatted}</td>
            <td class="text-end fw-bold">${t.amount_formatted}</td>
            <td>
                <a href="../receipts/view_receipt.php?id=${t.receipt_id}" class="btn btn-sm btn-outline-primary">
                    View Receipt
                </a>
            </td>
        </tr>
    `).join('');
}

// Render pagination
function renderPagination(pagination) {
    const container = document.getElementById('paginationContainer');
    
    if (pagination.total_pages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = '<nav aria-label="Page navigation"><ul class="pagination justify-content-center">';
    
    // Previous button
    if (pagination.has_prev) {
        html += `<li class="page-item"><a class="page-link" href="#" onclick="loadTransactions(${pagination.current_page - 1}); return false;">Previous</a></li>`;
    } else {
        html += '<li class="page-item disabled"><span class="page-link">Previous</span></li>';
    }
    
    // Page numbers
    const start = Math.max(1, pagination.current_page - 2);
    const end = Math.min(pagination.total_pages, pagination.current_page + 2);
    
    for (let i = start; i <= end; i++) {
        const active = i === pagination.current_page ? ' active' : '';
        html += `<li class="page-item${active}"><a class="page-link" href="#" onclick="loadTransactions(${i}); return false;">${i}</a></li>`;
    }
    
    // Next button
    if (pagination.has_next) {
        html += `<li class="page-item"><a class="page-link" href="#" onclick="loadTransactions(${pagination.current_page + 1}); return false;">Next</a></li>`;
    } else {
        html += '<li class="page-item disabled"><span class="page-link">Next</span></li>';
    }
    
    html += '</ul></nav>';
    container.innerHTML = html;
}

// Auto-refresh statistics every 30 seconds
setInterval(loadStatistics, 30000);

// Export transactions to CSV
function exportCSV() {
    let url = 'export_csv.php?';
    if (startDate) url += `start_date=${startDate}&`;
    if (endDate) url += `end_date=${endDate}`;
    
    window.location.href = url;
}
