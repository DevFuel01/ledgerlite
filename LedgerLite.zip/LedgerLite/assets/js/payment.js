/**
 * Payment Form JavaScript
 * LedgerLite - Financial Operating System
 */

document.addEventListener('DOMContentLoaded', function() {
    const paymentForm = document.getElementById('paymentForm');
    
    if (paymentForm) {
        paymentForm.addEventListener('submit', handlePaymentSubmit);
    }
});

async function handlePaymentSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    
    // Validate amount
    const amount = parseFloat(formData.get('amount'));
    if (amount <= 0) {
        showError('Please enter a valid amount');
        return;
    }
    
    // Show loading state
    setButtonLoading('submitBtn', true);
    
    try {
        const response = await fetchAPI('process_payment.php', {
            method: 'POST',
            body: formData
        });
        
        if (response.success) {
            showSuccess(response.message);
            
            // Redirect to receipt after 1.5 seconds
            setTimeout(() => {
                window.location.href = `../receipts/view_receipt.php?id=${response.data.receipt_id}`;
            }, 1500);
        } else {
            showError(response.message);
            setButtonLoading('submitBtn', false);
        }
    } catch (error) {
        showError('An error occurred. Please try again.');
        setButtonLoading('submitBtn', false);
    }
}

function showError(message) {
    const errorAlert = document.getElementById('errorAlert');
    const successAlert = document.getElementById('successAlert');
    errorAlert.textContent = message;
    errorAlert.classList.remove('d-none');
    successAlert.classList.add('d-none');
    
    // Scroll to alert
    errorAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function showSuccess(message) {
    const errorAlert = document.getElementById('errorAlert');
    const successAlert = document.getElementById('successAlert');
    successAlert.textContent = message;
    successAlert.classList.remove('d-none');
    errorAlert.classList.add('d-none');
    
    // Scroll to alert
    successAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
