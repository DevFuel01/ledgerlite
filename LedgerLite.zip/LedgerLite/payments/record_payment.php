<?php

/**
 * Record Payment Page
 * LedgerLite - Financial Operating System
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

$csrf_token = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Payment - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Record New Payment</h5>
                    </div>
                    <div class="card-body p-4">
                        <form id="paymentForm">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">

                            <div class="mb-3">
                                <label for="payerName" class="form-label">Payer Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="payerName" name="payer_name" required>
                            </div>

                            <div class="mb-3">
                                <label for="amount" class="form-label">Amount (<?php echo CURRENCY_SYMBOL; ?>) <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0.01" required>
                                <div class="form-text">Enter amount in <?php echo CURRENCY_CODE; ?></div>
                            </div>

                            <div class="mb-3">
                                <label for="paymentPurpose" class="form-label">Payment Purpose <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="paymentPurpose" name="payment_purpose" required>
                                <div class="form-text">e.g., School Fees, Training Course, Membership Fee</div>
                            </div>

                            <div class="mb-3">
                                <label for="paymentMethod" class="form-label">Payment Method <span class="text-danger">*</span></label>
                                <select class="form-select" id="paymentMethod" name="payment_method" required>
                                    <option value="">Select method...</option>
                                    <option value="cash">Cash</option>
                                    <option value="transfer">Bank Transfer</option>
                                    <option value="card">Card Payment</option>
                                    <option value="cheque">Cheque</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="paymentDate" class="form-label">Payment Date <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="paymentDate" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>

                            <div class="mb-4">
                                <label for="notes" class="form-label">Notes (Optional)</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                            </div>

                            <div class="alert alert-danger d-none" id="errorAlert"></div>
                            <div class="alert alert-success d-none" id="successAlert"></div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <span id="btnText">Record Payment</span>
                                    <span id="btnSpinner" class="spinner-border spinner-border-sm d-none" role="status"></span>
                                </button>
                                <a href="../dashboard/index.php" class="btn btn-outline-secondary">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/common.js"></script>
    <script src="../assets/js/payment.js"></script>
</body>

</html>