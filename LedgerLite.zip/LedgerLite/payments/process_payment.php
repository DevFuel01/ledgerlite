<?php

/**
 * Process Payment Handler
 * LedgerLite - Financial Operating System
 * 
 * Processes payment recording and creates receipt
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Check authentication
if (!check_auth(false)) {
    json_response(false, 'Unauthorized access');
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method');
}

try {
    $pdo = getDB();

    // Verify CSRF token
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        json_response(false, 'Invalid security token');
    }

    // Sanitize inputs
    $payer_name = sanitize_input($_POST['payer_name'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);
    $payment_purpose = sanitize_input($_POST['payment_purpose'] ?? '');
    $payment_method = sanitize_input($_POST['payment_method'] ?? '');
    $payment_date = sanitize_input($_POST['payment_date'] ?? '');
    $notes = sanitize_input($_POST['notes'] ?? '');

    // Validate required fields
    if (empty($payer_name) || $amount <= 0 || empty($payment_purpose) || empty($payment_method) || empty($payment_date)) {
        json_response(false, 'All required fields must be filled');
    }

    // Validate amount
    if ($amount <= 0 || $amount > 999999999.99) {
        json_response(false, 'Invalid payment amount');
    }

    // Validate payment method
    $valid_methods = ['cash', 'transfer', 'card', 'cheque', 'other'];
    if (!in_array($payment_method, $valid_methods)) {
        json_response(false, 'Invalid payment method');
    }

    // Validate date
    $date_obj = DateTime::createFromFormat('Y-m-d', $payment_date);
    if (!$date_obj) {
        json_response(false, 'Invalid payment date');
    }

    // Check for potential duplicate (same payer, amount, and date)
    $stmt = $pdo->prepare("
        SELECT id FROM payments 
        WHERE institution_id = ? 
        AND payer_name = ? 
        AND amount = ? 
        AND payment_date = ? 
        AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    ");
    $stmt->execute([get_institution_id(), $payer_name, $amount, $payment_date]);
    if ($stmt->fetch()) {
        json_response(false, 'A similar payment was just recorded. Please verify this is not a duplicate.');
    }

    // Start transaction
    $pdo->beginTransaction();

    try {
        // Generate transaction ID
        $transaction_id = generate_transaction_id($pdo);

        // Insert payment
        $stmt = $pdo->prepare("
            INSERT INTO payments 
            (institution_id, transaction_id, payer_name, amount, payment_purpose, payment_method, payment_date, recorded_by, notes, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->execute([
            get_institution_id(),
            $transaction_id,
            $payer_name,
            $amount,
            $payment_purpose,
            $payment_method,
            $payment_date,
            get_user_id(),
            $notes
        ]);
        $payment_id = $pdo->lastInsertId();

        // Generate receipt
        $receipt_number = generate_receipt_number($pdo);
        $stmt = $pdo->prepare("
            INSERT INTO receipts (payment_id, receipt_number) 
            VALUES (?, ?)
        ");
        $stmt->execute([$payment_id, $receipt_number]);
        $receipt_id = $pdo->lastInsertId();

        // Commit transaction
        $pdo->commit();

        // Log action
        log_audit($pdo, 'payment_created', 'payment', $payment_id, "Payment recorded for {$payer_name}");

        json_response(true, 'Payment recorded successfully!', [
            'payment_id' => $payment_id,
            'transaction_id' => $transaction_id,
            'receipt_id' => $receipt_id,
            'receipt_number' => $receipt_number
        ]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Payment processing error: " . $e->getMessage());
        json_response(false, 'Failed to record payment. Please try again.');
    }
} catch (Exception $e) {
    error_log("Payment processing error: " . $e->getMessage());
    json_response(false, 'An unexpected error occurred. Please try again.');
}
