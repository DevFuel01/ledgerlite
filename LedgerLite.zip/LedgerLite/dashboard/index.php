<?php

/**
 * Dashboard - Main Page
 * LedgerLite - Financial Operating System
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

$pdo = getDB();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-4">
        <!-- Welcome Section -->
        <div class="row mb-4">
            <div class="col-12">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
                <p class="text-muted"><?php echo htmlspecialchars($_SESSION['institution_name']); ?></p>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4" id="statsCards">
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Total Income</h6>
                                <h3 class="mb-0" id="totalIncome">
                                    <span class="spinner-border spinner-border-sm" role="status"></span>
                                </h3>
                            </div>
                            <div class="bg-primary bg-opacity-10 p-3 rounded">
                                <svg width="24" height="24" fill="currentColor" class="text-primary">
                                    <use href="#icon-wallet" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">Today's Income</h6>
                                <h3 class="mb-0" id="todayIncome">
                                    <span class="spinner-border spinner-border-sm" role="status"></span>
                                </h3>
                            </div>
                            <div class="bg-success bg-opacity-10 p-3 rounded">
                                <svg width="24" height="24" fill="currentColor" class="text-success">
                                    <use href="#icon-calendar" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-1">This Month</h6>
                                <h3 class="mb-0" id="monthIncome">
                                    <span class="spinner-border spinner-border-sm" role="status"></span>
                                </h3>
                            </div>
                            <div class="bg-info bg-opacity-10 p-3 rounded">
                                <svg width="24" height="24" fill="currentColor" class="text-info">
                                    <use href="#icon-chart" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <a href="../payments/record_payment.php" class="btn btn-primary btn-lg">
                    <svg width="20" height="20" fill="currentColor" class="me-2">
                        <use href="#icon-plus" />
                    </svg>
                    Record New Payment
                </a>
            </div>
        </div>

        <!-- Transaction History -->
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h5 class="mb-0">Transaction History</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="row g-2">
                            <div class="col-md-4">
                                <input type="date" class="form-control form-control-sm" id="startDate" placeholder="Start Date">
                            </div>
                            <div class="col-md-4">
                                <input type="date" class="form-control form-control-sm" id="endDate" placeholder="End Date">
                            </div>
                            <div class="col-md-4">
                                <button onclick="exportCSV()" class="btn btn-success btn-sm w-100">
                                    <svg width="16" height="16" fill="currentColor" class="me-1">
                                        <use href="#icon-download" />
                                    </svg>
                                    Export CSV
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Transaction ID</th>
                                <th>Payer</th>
                                <th>Purpose</th>
                                <th>Method</th>
                                <th class="text-end">Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="transactionTable">
                            <tr>
                                <td colspan="7" class="text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div id="paginationContainer"></div>
            </div>
        </div>
    </div>

    <!-- SVG Icons -->
    <svg style="display: none;">
        <symbol id="icon-wallet" viewBox="0 0 24 24">
            <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" />
        </symbol>
        <symbol id="icon-calendar" viewBox="0 0 24 24">
            <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z" />
        </symbol>
        <symbol id="icon-chart" viewBox="0 0 24 24">
            <path d="M3.5 18.49l6-6.01 4 4L22 6.92l-1.41-1.41-7.09 7.97-4-4L2 16.99z" />
        </symbol>
        <symbol id="icon-plus" viewBox="0 0 24 24">
            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
        </symbol>
        <symbol id="icon-download" viewBox="0 0 24 24">
            <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
        </symbol>
    </svg>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/common.js"></script>
    <script src="../assets/js/dashboard.js"></script>
</body>

</html>