<?php

/**
 * Get Analytics API
 * LedgerLite - Financial Operating System
 * 
 * Returns analytics data for dashboard
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Check authentication
if (!check_auth(false)) {
    json_response(false, 'Unauthorized access');
}

try {
    $pdo = getDB();
    $institution_id = get_institution_id();

    // 1. Highest payment day
    $stmt = $pdo->prepare("
        SELECT payment_date, SUM(amount) as total
        FROM payments
        WHERE institution_id = ? AND status = 'completed'
        GROUP BY payment_date
        ORDER BY total DESC
        LIMIT 1
    ");
    $stmt->execute([$institution_id]);
    $highest_day = $stmt->fetch();

    // 2. Average daily income (last 30 days)
    $stmt = $pdo->prepare("
        SELECT AVG(daily_total) as avg_daily
        FROM (
            SELECT DATE(payment_date) as date, SUM(amount) as daily_total
            FROM payments
            WHERE institution_id = ? 
            AND status = 'completed'
            AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY DATE(payment_date)
        ) as daily_totals
    ");
    $stmt->execute([$institution_id]);
    $avg_result = $stmt->fetch();
    $avg_daily = $avg_result['avg_daily'] ?? 0;

    // 3. Payment method breakdown
    $stmt = $pdo->prepare("
        SELECT 
            payment_method,
            COUNT(*) as count,
            SUM(amount) as total
        FROM payments
        WHERE institution_id = ? AND status = 'completed'
        GROUP BY payment_method
        ORDER BY total DESC
    ");
    $stmt->execute([$institution_id]);
    $method_breakdown = $stmt->fetchAll();

    // 4. Monthly trend (last 6 months)
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%Y-%m') as month,
            SUM(amount) as total,
            COUNT(*) as count
        FROM payments
        WHERE institution_id = ? 
        AND status = 'completed'
        AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute([$institution_id]);
    $monthly_trend = $stmt->fetchAll();

    // 5. Top payers (top 5)
    $stmt = $pdo->prepare("
        SELECT 
            payer_name,
            COUNT(*) as payment_count,
            SUM(amount) as total_paid
        FROM payments
        WHERE institution_id = ? AND status = 'completed'
        GROUP BY payer_name
        ORDER BY total_paid DESC
        LIMIT 5
    ");
    $stmt->execute([$institution_id]);
    $top_payers = $stmt->fetchAll();

    json_response(true, 'Analytics retrieved successfully', [
        'highest_day' => [
            'date' => $highest_day['payment_date'] ?? null,
            'amount' => floatval($highest_day['total'] ?? 0),
            'formatted' => format_currency($highest_day['total'] ?? 0),
            'formatted_date' => $highest_day['payment_date'] ? format_date($highest_day['payment_date']) : 'N/A'
        ],
        'avg_daily_income' => [
            'amount' => floatval($avg_daily),
            'formatted' => format_currency($avg_daily)
        ],
        'payment_methods' => array_map(function ($m) {
            return [
                'method' => $m['payment_method'],
                'method_formatted' => ucfirst(str_replace('_', ' ', $m['payment_method'])),
                'count' => intval($m['count']),
                'total' => floatval($m['total']),
                'formatted' => format_currency($m['total'])
            ];
        }, $method_breakdown),
        'monthly_trend' => array_map(function ($m) {
            return [
                'month' => $m['month'],
                'total' => floatval($m['total']),
                'count' => intval($m['count']),
                'formatted' => format_currency($m['total'])
            ];
        }, $monthly_trend),
        'top_payers' => array_map(function ($p) {
            return [
                'name' => $p['payer_name'],
                'payment_count' => intval($p['payment_count']),
                'total_paid' => floatval($p['total_paid']),
                'formatted' => format_currency($p['total_paid'])
            ];
        }, $top_payers)
    ]);
} catch (Exception $e) {
    error_log("Analytics error: " . $e->getMessage());
    json_response(false, 'Failed to retrieve analytics');
}
