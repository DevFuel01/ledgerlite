<?php

/**
 * Export Transactions to CSV
 * LedgerLite - Financial Operating System
 * 
 * Exports transaction data as CSV file for accounting, backup, and offline review
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

$pdo = getDB();
$institution_id = get_institution_id();

// Get date filters
$start_date = $_GET['start_date'] ?? null;
$end_date = $_GET['end_date'] ?? null;

// Build WHERE clause
$where = "WHERE institution_id = ? AND status = 'completed'";
$params = [$institution_id];

if ($start_date) {
    $where .= " AND payment_date >= ?";
    $params[] = $start_date;
}

if ($end_date) {
    $where .= " AND payment_date <= ?";
    $params[] = $end_date;
}

// Get transactions
$stmt = $pdo->prepare("
    SELECT 
        payment_date,
        transaction_id,
        payer_name,
        amount,
        payment_purpose,
        payment_method,
        notes,
        created_at
    FROM payments
    $where
    ORDER BY payment_date DESC, created_at DESC
");
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Generate filename with date range
$filename = 'transactions_' . date('Y-m-d');
if ($start_date && $end_date) {
    $filename = 'transactions_' . $start_date . '_to_' . $end_date;
} elseif ($start_date) {
    $filename = 'transactions_from_' . $start_date;
} elseif ($end_date) {
    $filename = 'transactions_until_' . $end_date;
}
$filename .= '.csv';

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Open output stream
$output = fopen('php://output', 'w');

// Add BOM for UTF-8 (helps Excel recognize encoding)
fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

// Write CSV header
fputcsv($output, [
    'Date',
    'Transaction ID',
    'Payer Name',
    'Amount (' . CURRENCY_CODE . ')',
    'Purpose',
    'Payment Method',
    'Notes',
    'Recorded At'
]);

// Write data rows
foreach ($transactions as $t) {
    fputcsv($output, [
        $t['payment_date'],
        $t['transaction_id'],
        $t['payer_name'],
        number_format($t['amount'], 2, '.', ''),
        $t['payment_purpose'],
        ucfirst(str_replace('_', ' ', $t['payment_method'])),
        $t['notes'] ?? '',
        $t['created_at']
    ]);
}

// Log export action
log_audit($pdo, 'transactions_exported', null, null, count($transactions) . ' transactions exported to CSV');

fclose($output);
exit;
