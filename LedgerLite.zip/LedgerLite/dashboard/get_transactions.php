<?php

/**
 * Get Transactions API
 * LedgerLite - Financial Operating System
 * 
 * Returns paginated transaction history with filtering
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Check authentication
if (!check_auth(false)) {
    json_response(false, 'Unauthorized access');
}

try {
    $pdo = getDB();
    $institution_id = get_institution_id();

    // Get parameters
    $page = intval($_GET['page'] ?? 1);
    $per_page = intval($_GET['per_page'] ?? RECORDS_PER_PAGE);
    $start_date = $_GET['start_date'] ?? null;
    $end_date = $_GET['end_date'] ?? null;

    // Build WHERE clause
    $where = "WHERE p.institution_id = ?";
    $params = [$institution_id];

    if ($start_date) {
        $where .= " AND p.payment_date >= ?";
        $params[] = $start_date;
    }

    if ($end_date) {
        $where .= " AND p.payment_date <= ?";
        $params[] = $end_date;
    }

    // Get total count
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM payments p $where");
    $stmt->execute($params);
    $total_records = $stmt->fetch()['count'];

    // Calculate pagination
    $pagination = get_pagination($total_records, $page, $per_page);

    // Get transactions
    $stmt = $pdo->prepare("
        SELECT 
            p.*,
            r.receipt_number,
            r.id as receipt_id,
            u.full_name as recorded_by_name
        FROM payments p
        LEFT JOIN receipts r ON p.id = r.payment_id
        LEFT JOIN users u ON p.recorded_by = u.id
        $where
        ORDER BY p.payment_date DESC, p.created_at DESC
        LIMIT ? OFFSET ?
    ");
    $params[] = $pagination['per_page'];
    $params[] = $pagination['offset'];
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();

    // Format transactions
    $formatted_transactions = array_map(function ($t) {
        return [
            'id' => $t['id'],
            'transaction_id' => $t['transaction_id'],
            'payer_name' => $t['payer_name'],
            'amount' => floatval($t['amount']),
            'amount_formatted' => format_currency($t['amount']),
            'payment_purpose' => $t['payment_purpose'],
            'payment_method' => $t['payment_method'],
            'payment_method_formatted' => ucfirst(str_replace('_', ' ', $t['payment_method'])),
            'payment_date' => $t['payment_date'],
            'payment_date_formatted' => format_date($t['payment_date']),
            'status' => $t['status'],
            'receipt_id' => $t['receipt_id'],
            'receipt_number' => $t['receipt_number'],
            'recorded_by' => $t['recorded_by_name'],
            'created_at' => $t['created_at']
        ];
    }, $transactions);

    json_response(true, 'Transactions retrieved successfully', [
        'transactions' => $formatted_transactions,
        'pagination' => $pagination
    ]);
} catch (Exception $e) {
    error_log("Transactions error: " . $e->getMessage());
    json_response(false, 'Failed to retrieve transactions');
}
