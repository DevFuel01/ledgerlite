<?php

/**
 * Analytics Page
 * LedgerLite - Financial Operating System
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

$pdo = getDB();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-4">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <h2>Analytics & Insights</h2>
                <p class="text-muted">Financial performance and payment trends</p>
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h6 class="text-muted mb-2">Highest Payment Day</h6>
                        <h3 class="mb-1" id="highestDay">
                            <span class="spinner-border spinner-border-sm" role="status"></span>
                        </h3>
                        <p class="mb-0 text-success fw-bold" id="highestDayAmount">-</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h6 class="text-muted mb-2">Average Daily Income</h6>
                        <h3 class="mb-1" id="avgDaily">
                            <span class="spinner-border spinner-border-sm" role="status"></span>
                        </h3>
                        <p class="mb-0 text-muted small">Last 30 days</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="row mb-4">
            <!-- Payment Method Breakdown -->
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Payment Method Breakdown</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="methodChart" height="250"></canvas>
                    </div>
                </div>
            </div>

            <!-- Monthly Trend -->
            <div class="col-md-6 mb-3">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Monthly Trend (Last 6 Months)</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="trendChart" height="250"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Payers -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">Top 5 Payers</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th width="50">#</th>
                                        <th>Payer Name</th>
                                        <th>Payments</th>
                                        <th class="text-end">Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody id="topPayersTable">
                                    <tr>
                                        <td colspan="4" class="text-center">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../assets/js/common.js"></script>
    <script src="../assets/js/analytics.js"></script>
</body>

</html>