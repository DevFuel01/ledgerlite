<?php

/**
 * Get Statistics API
 * LedgerLite - Financial Operating System
 * 
 * Returns financial statistics for dashboard
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Check authentication
if (!check_auth(false)) {
    json_response(false, 'Unauthorized access');
}

try {
    $pdo = getDB();
    $institution_id = get_institution_id();

    // Get total income
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE institution_id = ? AND status = 'completed'
    ");
    $stmt->execute([$institution_id]);
    $total_income = $stmt->fetch()['total'];

    // Get today's income
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE institution_id = ? 
        AND status = 'completed'
        AND DATE(payment_date) = CURDATE()
    ");
    $stmt->execute([$institution_id]);
    $today_income = $stmt->fetch()['total'];

    // Get this month's income
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE institution_id = ? 
        AND status = 'completed'
        AND YEAR(payment_date) = YEAR(CURDATE())
        AND MONTH(payment_date) = MONTH(CURDATE())
    ");
    $stmt->execute([$institution_id]);
    $month_income = $stmt->fetch()['total'];

    // Get transaction count
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM payments 
        WHERE institution_id = ? AND status = 'completed'
    ");
    $stmt->execute([$institution_id]);
    $transaction_count = $stmt->fetch()['count'];

    json_response(true, 'Statistics retrieved successfully', [
        'total_income' => floatval($total_income),
        'today_income' => floatval($today_income),
        'month_income' => floatval($month_income),
        'transaction_count' => intval($transaction_count),
        'formatted' => [
            'total_income' => format_currency($total_income),
            'today_income' => format_currency($today_income),
            'month_income' => format_currency($month_income)
        ]
    ]);
} catch (Exception $e) {
    error_log("Statistics error: " . $e->getMessage());
    json_response(false, 'Failed to retrieve statistics');
}
