<?php

/**
 * Institution Profile Page
 * LedgerLite - Financial Operating System
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

$pdo = getDB();
$csrf_token = generate_csrf_token();

// Get institution details
$stmt = $pdo->prepare("SELECT * FROM institutions WHERE id = ?");
$stmt->execute([get_institution_id()]);
$institution = $stmt->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $name = sanitize_input($_POST['name'] ?? '');
        $type = sanitize_input($_POST['type'] ?? '');
        $email = sanitize_input($_POST['email'] ?? '');
        $phone = sanitize_input($_POST['phone'] ?? '');
        $address = sanitize_input($_POST['address'] ?? '');

        if (!empty($name) && !empty($type) && !empty($email)) {
            $stmt = $pdo->prepare("
                UPDATE institutions 
                SET name = ?, type = ?, email = ?, phone = ?, address = ? 
                WHERE id = ?
            ");

            if ($stmt->execute([$name, $type, $email, $phone, $address, get_institution_id()])) {
                $_SESSION['institution_name'] = $name;
                log_audit($pdo, 'institution_updated', 'institution', get_institution_id(), 'Institution profile updated');
                $success_message = 'Profile updated successfully!';

                // Refresh institution data
                $stmt = $pdo->prepare("SELECT * FROM institutions WHERE id = ?");
                $stmt->execute([get_institution_id()]);
                $institution = $stmt->fetch();
            } else {
                $error_message = 'Failed to update profile. Please try again.';
            }
        } else {
            $error_message = 'Please fill in all required fields.';
        }
    } else {
        $error_message = 'Invalid security token.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution Profile - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Institution Profile</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if (isset($success_message)): ?>
                            <div class="alert alert-success"><?php echo $success_message; ?></div>
                        <?php endif; ?>

                        <?php if (isset($error_message)): ?>
                            <div class="alert alert-danger"><?php echo $error_message; ?></div>
                        <?php endif; ?>

                        <form method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                            <input type="hidden" name="update_profile" value="1">

                            <div class="mb-3">
                                <label for="name" class="form-label">Institution Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($institution['name']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="type" class="form-label">Institution Type <span class="text-danger">*</span></label>
                                <select class="form-select" id="type" name="type" required>
                                    <option value="school" <?php echo $institution['type'] === 'school' ? 'selected' : ''; ?>>School</option>
                                    <option value="training_center" <?php echo $institution['type'] === 'training_center' ? 'selected' : ''; ?>>Training Center</option>
                                    <option value="community_program" <?php echo $institution['type'] === 'community_program' ? 'selected' : ''; ?>>Community Program</option>
                                    <option value="other" <?php echo $institution['type'] === 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($institution['email']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($institution['phone'] ?? ''); ?>">
                            </div>

                            <div class="mb-4">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($institution['address'] ?? ''); ?></textarea>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Update Profile</button>
                                <a href="../dashboard/index.php" class="btn btn-outline-secondary">Back to Dashboard</a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Institution Info -->
                <div class="card shadow-sm mt-3">
                    <div class="card-body">
                        <h6 class="text-muted mb-3">Institution Information</h6>
                        <p class="mb-2"><strong>Created:</strong> <?php echo format_datetime($institution['created_at']); ?></p>
                        <p class="mb-0"><strong>Last Updated:</strong> <?php echo format_datetime($institution['updated_at']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>