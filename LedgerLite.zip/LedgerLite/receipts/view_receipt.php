<?php

/**
 * View Receipt Page
 * LedgerLite - Financial Operating System
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

// Check authentication
check_auth();

// Get receipt ID from URL
$receipt_id = intval($_GET['id'] ?? 0);

if ($receipt_id <= 0) {
    header('Location: ../dashboard/index.php');
    exit();
}

$pdo = getDB();

// Get receipt and payment details
$stmt = $pdo->prepare("
    SELECT r.*, p.*, i.name as institution_name, i.email as institution_email, i.phone as institution_phone, i.address as institution_address
    FROM receipts r
    JOIN payments p ON r.payment_id = p.id
    JOIN institutions i ON p.institution_id = i.id
    WHERE r.id = ? AND p.institution_id = ?
");
$stmt->execute([$receipt_id, get_institution_id()]);
$receipt = $stmt->fetch();

if (!$receipt) {
    header('Location: ../dashboard/index.php');
    exit();
}

// Update download count
$stmt = $pdo->prepare("UPDATE receipts SET downloaded_count = downloaded_count + 1, last_downloaded = NOW() WHERE id = ?");
$stmt->execute([$receipt_id]);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt <?php echo htmlspecialchars($receipt['receipt_number']); ?> - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
    <style>
        @media print {
            .no-print {
                display: none;
            }

            .receipt-container {
                box-shadow: none !important;
            }
        }
    </style>
</head>

<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-4 mb-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <!-- Action Buttons -->
                <div class="mb-3 no-print">
                    <button onclick="window.print()" class="btn btn-primary">
                        <i class="bi bi-printer"></i> Print Receipt
                    </button>
                    <a href="../dashboard/index.php" class="btn btn-outline-secondary">Back to Dashboard</a>
                </div>

                <!-- Receipt -->
                <div class="card shadow receipt-container" id="receiptContent">
                    <div class="card-body p-5">
                        <!-- Header -->
                        <div class="text-center mb-4 pb-3 border-bottom">
                            <h2 class="mb-1"><?php echo htmlspecialchars($receipt['institution_name']); ?></h2>
                            <?php if ($receipt['institution_address']): ?>
                                <p class="mb-1 text-muted"><?php echo htmlspecialchars($receipt['institution_address']); ?></p>
                            <?php endif; ?>
                            <p class="mb-0 text-muted">
                                <?php if ($receipt['institution_email']): ?>
                                    Email: <?php echo htmlspecialchars($receipt['institution_email']); ?>
                                <?php endif; ?>
                                <?php if ($receipt['institution_phone']): ?>
                                    | Phone: <?php echo htmlspecialchars($receipt['institution_phone']); ?>
                                <?php endif; ?>
                            </p>
                        </div>

                        <!-- Receipt Title -->
                        <div class="text-center mb-4">
                            <h3 class="text-primary">PAYMENT RECEIPT</h3>
                            <p class="mb-0">Receipt No: <strong><?php echo htmlspecialchars($receipt['receipt_number']); ?></strong></p>
                        </div>

                        <!-- Receipt Details -->
                        <div class="row mb-4">
                            <div class="col-6">
                                <p class="mb-2"><strong>Transaction ID:</strong><br><?php echo htmlspecialchars($receipt['transaction_id']); ?></p>
                                <p class="mb-2"><strong>Payment Date:</strong><br><?php echo format_date($receipt['payment_date']); ?></p>
                            </div>
                            <div class="col-6 text-end">
                                <p class="mb-2"><strong>Receipt Date:</strong><br><?php echo format_datetime($receipt['generated_at']); ?></p>
                                <p class="mb-2"><strong>Payment Method:</strong><br><?php echo ucfirst(str_replace('_', ' ', $receipt['payment_method'])); ?></p>
                            </div>
                        </div>

                        <!-- Payer Information -->
                        <div class="mb-4 p-3 bg-light rounded">
                            <h6 class="text-muted mb-2">RECEIVED FROM</h6>
                            <p class="mb-0 h5"><?php echo htmlspecialchars($receipt['payer_name']); ?></p>
                        </div>

                        <!-- Payment Details -->
                        <table class="table table-bordered mb-4">
                            <thead class="table-light">
                                <tr>
                                    <th>Description</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo htmlspecialchars($receipt['payment_purpose']); ?></td>
                                    <td class="text-end"><?php echo format_currency($receipt['amount']); ?></td>
                                </tr>
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <th>TOTAL PAID</th>
                                    <th class="text-end h5 mb-0"><?php echo format_currency($receipt['amount']); ?></th>
                                </tr>
                            </tfoot>
                        </table>

                        <?php if ($receipt['notes']): ?>
                            <!-- Notes -->
                            <div class="mb-4">
                                <h6 class="text-muted">Notes:</h6>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($receipt['notes'])); ?></p>
                            </div>
                        <?php endif; ?>

                        <!-- Footer -->
                        <div class="mt-5 pt-4 border-top text-center">
                            <p class="mb-1 text-muted small">This is an official receipt generated by LedgerLite</p>
                            <p class="mb-0 text-muted small">For inquiries, please contact <?php echo htmlspecialchars($receipt['institution_email']); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>