<?php

/**
 * Logout Handler
 * LedgerLite - Financial Operating System
 * 
 * Destroys user session and redirects to login
 */

require_once '../config/config.php';
require_once '../includes/security.php';

// Log logout action before destroying session
if (isset($_SESSION['user_id'])) {
    $pdo = getDB();
    log_audit($pdo, 'user_logout', 'user', $_SESSION['user_id'], 'User logged out');
}

// Destroy session
session_unset();
session_destroy();

// Clear remember me cookie if exists
if (isset($_COOKIE['remember_user'])) {
    setcookie('remember_user', '', time() - 3600, '/');
}

// Redirect to login
header('Location: login.php');
exit();
