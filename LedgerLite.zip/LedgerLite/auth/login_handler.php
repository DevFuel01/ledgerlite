<?php

/**
 * Login Handler
 * LedgerLite - Financial Operating System
 * 
 * Processes user authentication
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method');
}

try {
    $pdo = getDB();

    // Sanitize inputs
    $email = sanitize_input($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember_me = isset($_POST['remember_me']);

    // Validate required fields
    if (empty($email) || empty($password)) {
        json_response(false, 'Email and password are required');
    }

    // Validate email format
    if (!validate_email($email)) {
        json_response(false, 'Invalid email address');
    }

    // Get user from database
    $stmt = $pdo->prepare("
        SELECT u.*, i.name as institution_name 
        FROM users u 
        JOIN institutions i ON u.institution_id = i.id 
        WHERE u.email = ? AND u.is_active = 1
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Check if user exists
    if (!$user) {
        json_response(false, 'Invalid email or password');
    }

    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        // Log failed login attempt
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, institution_id, action, description, ip_address) 
            VALUES (?, ?, 'login_failed', 'Failed login attempt', ?)
        ");
        $stmt->execute([$user['id'], $user['institution_id'], get_client_ip()]);

        json_response(false, 'Invalid email or password');
    }

    // Update last login
    $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    $stmt->execute([$user['id']]);

    // Create session
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['institution_id'] = $user['institution_id'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['institution_name'] = $user['institution_name'];
    $_SESSION['last_activity'] = time();

    // Set remember me cookie (optional enhancement)
    if ($remember_me) {
        // This is a placeholder - implement secure remember me token in production
        setcookie('remember_user', $user['id'], time() + (86400 * 30), '/'); // 30 days
    }

    // Log successful login
    log_audit($pdo, 'user_login', 'user', $user['id'], 'User logged in successfully');

    json_response(true, 'Login successful! Redirecting...', [
        'user_id' => $user['id'],
        'user_name' => $user['full_name']
    ]);
} catch (Exception $e) {
    error_log("Login error: " . $e->getMessage());
    json_response(false, 'An unexpected error occurred. Please try again.');
}
