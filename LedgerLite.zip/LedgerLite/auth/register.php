<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - LedgerLite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/main.css">
</head>

<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <h1 class="h3 mb-2">Create Account</h1>
                            <p class="text-muted">Join LedgerLite to manage your institution's finances</p>
                        </div>

                        <form id="registerForm">
                            <!-- Institution Details -->
                            <h6 class="text-muted mb-3">Institution Details</h6>

                            <div class="mb-3">
                                <label for="institutionName" class="form-label">Institution Name</label>
                                <input type="text" class="form-control" id="institutionName" name="institution_name" placeholder="e.g., ABC Academy" required>
                            </div>

                            <div class="mb-3">
                                <label for="institutionType" class="form-label">Institution Type</label>
                                <select class="form-select" id="institutionType" name="institution_type" required>
                                    <option value="">Select type...</option>
                                    <option value="school">School</option>
                                    <option value="training_center">Training Center</option>
                                    <option value="community_program">Community Program</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="institutionEmail" class="form-label">Institution Email</label>
                                <input type="email" class="form-control" id="institutionEmail" name="institution_email" placeholder="info@yourinstitution.com" required>
                            </div>

                            <div class="mb-3">
                                <label for="institutionPhone" class="form-label">Institution Phone</label>
                                <input type="tel" class="form-control" id="institutionPhone" name="institution_phone" placeholder="+234-XXX-XXX-XXXX" required>
                            </div>

                            <hr class="my-4">

                            <!-- Admin User Details -->
                            <h6 class="text-muted mb-3">Admin Account</h6>

                            <div class="mb-3">
                                <label for="fullName" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="fullName" name="full_name" placeholder="John Doe" required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="your.email@example.com" required>
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="+234-XXX-XXX-XXXX" required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="At least 8 characters" required>
                                <div class="form-text">Minimum 8 characters, include letters and numbers</div>
                                <div id="passwordStrength" class="mt-2"></div>
                            </div>

                            <div class="mb-4">
                                <label for="confirmPassword" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="confirmPassword" name="confirm_password" placeholder="Re-enter your password" required>
                            </div>

                            <div class="alert alert-danger d-none" id="errorAlert"></div>
                            <div class="alert alert-success d-none" id="successAlert"></div>

                            <button type="submit" class="btn btn-primary w-100 mb-3" id="submitBtn">
                                <span id="btnText">Create Account</span>
                                <span id="btnSpinner" class="spinner-border spinner-border-sm d-none" role="status"></span>
                            </button>

                            <div class="text-center">
                                <p class="mb-0">Already have an account? <a href="login.php">Login here</a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/common.js"></script>
    <script>
        // Password strength indicator
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthDiv = document.getElementById('passwordStrength');

            if (password.length === 0) {
                strengthDiv.innerHTML = '';
                return;
            }

            let strength = 0;
            if (password.length >= 8) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;

            const labels = ['Weak', 'Fair', 'Good', 'Strong'];
            const colors = ['danger', 'warning', 'info', 'success'];

            strengthDiv.innerHTML = `<small class="text-${colors[strength - 1]}">Password strength: ${labels[strength - 1]}</small>`;
        });

        // Form submission
        document.getElementById('registerForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // Validate passwords match
            if (password !== confirmPassword) {
                showError('Passwords do not match');
                return;
            }

            // Validate password strength
            if (password.length < 8) {
                showError('Password must be at least 8 characters long');
                return;
            }

            if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
                showError('Password must contain both letters and numbers');
                return;
            }

            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            const btnText = document.getElementById('btnText');
            const btnSpinner = document.getElementById('btnSpinner');

            submitBtn.disabled = true;
            btnText.classList.add('d-none');
            btnSpinner.classList.remove('d-none');

            // Submit form
            const formData = new FormData(this);

            try {
                const response = await fetch('register_handler.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    showSuccess(result.message);
                    setTimeout(() => {
                        window.location.href = '../dashboard/index.php';
                    }, 1500);
                } else {
                    showError(result.message);
                    submitBtn.disabled = false;
                    btnText.classList.remove('d-none');
                    btnSpinner.classList.add('d-none');
                }
            } catch (error) {
                showError('An error occurred. Please try again.');
                submitBtn.disabled = false;
                btnText.classList.remove('d-none');
                btnSpinner.classList.add('d-none');
            }
        });

        function showError(message) {
            const errorAlert = document.getElementById('errorAlert');
            const successAlert = document.getElementById('successAlert');
            errorAlert.textContent = message;
            errorAlert.classList.remove('d-none');
            successAlert.classList.add('d-none');
        }

        function showSuccess(message) {
            const errorAlert = document.getElementById('errorAlert');
            const successAlert = document.getElementById('successAlert');
            successAlert.textContent = message;
            successAlert.classList.remove('d-none');
            errorAlert.classList.add('d-none');
        }
    </script>
</body>

</html>