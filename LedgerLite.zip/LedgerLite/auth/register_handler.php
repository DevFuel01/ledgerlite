<?php

/**
 * Registration Handler
 * LedgerLite - Financial Operating System
 * 
 * Processes new user and institution registration
 */

require_once '../config/config.php';
require_once '../includes/security.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method');
}

try {
    $pdo = getDB();

    // Sanitize inputs
    $institution_name = sanitize_input($_POST['institution_name'] ?? '');
    $institution_type = sanitize_input($_POST['institution_type'] ?? '');
    $institution_email = sanitize_input($_POST['institution_email'] ?? '');
    $institution_phone = sanitize_input($_POST['institution_phone'] ?? '');
    $full_name = sanitize_input($_POST['full_name'] ?? '');
    $email = sanitize_input($_POST['email'] ?? '');
    $phone = sanitize_input($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validate required fields
    if (
        empty($institution_name) || empty($institution_type) || empty($institution_email) ||
        empty($full_name) || empty($email) || empty($password)
    ) {
        json_response(false, 'All required fields must be filled');
    }

    // Validate email formats
    if (!validate_email($institution_email)) {
        json_response(false, 'Invalid institution email address');
    }

    if (!validate_email($email)) {
        json_response(false, 'Invalid admin email address');
    }

    // Validate password
    $password_check = validate_password($password);
    if (!$password_check['valid']) {
        json_response(false, $password_check['message']);
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        json_response(false, 'An account with this email already exists');
    }

    // Start transaction
    $pdo->beginTransaction();

    try {
        // Insert institution
        $stmt = $pdo->prepare("
            INSERT INTO institutions (name, type, email, phone) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$institution_name, $institution_type, $institution_email, $institution_phone]);
        $institution_id = $pdo->lastInsertId();

        // Hash password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Insert user
        $stmt = $pdo->prepare("
            INSERT INTO users (institution_id, full_name, email, password_hash, phone, role) 
            VALUES (?, ?, ?, ?, ?, 'admin')
        ");
        $stmt->execute([$institution_id, $full_name, $email, $password_hash, $phone]);
        $user_id = $pdo->lastInsertId();

        // Commit transaction
        $pdo->commit();

        // Create session
        $_SESSION['user_id'] = $user_id;
        $_SESSION['institution_id'] = $institution_id;
        $_SESSION['user_name'] = $full_name;
        $_SESSION['user_email'] = $email;
        $_SESSION['institution_name'] = $institution_name;
        $_SESSION['last_activity'] = time();

        // Log registration
        log_audit($pdo, 'user_registered', 'user', $user_id, 'New user and institution registered');

        json_response(true, 'Registration successful! Redirecting to dashboard...', [
            'user_id' => $user_id,
            'institution_id' => $institution_id
        ]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Registration error: " . $e->getMessage());
        json_response(false, 'Registration failed. Please try again.');
    }
} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    json_response(false, 'An unexpected error occurred. Please try again.');
}
